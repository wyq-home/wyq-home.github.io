# Introduced by Yanqing Wang.
#
# The purpose of this file is to behave as an "addon" to ".p10k.zsh". So that .p10k.zsh to be shared
# across hosts, but the "addon"s can be different on each host.

typeset -g POWERLEVEL9K_DIR_BACKGROUND=238
p10k reload
