#!/usr/bin/env python3

import os
import yaml
from loguru import logger
import traceback
from enum import Enum
import subprocess
import time
import argparse
import socket
import copy
from typing import Callable
import functools

_CONFIG_BASE_DIR = '../dotfiles'
_CONFIG_FILE_NAME = 'dotfiles_deploy.yaml'
_FILE_DIR = os.path.dirname(os.path.realpath(__file__))


class ActionOnExist(Enum):
    REPLACE = 1
    BACKUP_AND_REPLACE = 2
    KEEP_OLD_AND_WARN = 3


_DEFAULT_ACTION_ON_EXIST_CONFIG = 'BACKUP_AND_REPLACE'


class _LabelFilter:
    @classmethod
    def name(cls) -> str:
        raise NotImplementedError('label name is not implemented.')

    @classmethod
    def filter(cls, label_value) -> bool:
        raise NotImplementedError('filter is not implemented')


class _HostsLabelFilter(_LabelFilter):
    @classmethod
    def name(cls) -> str:
        return 'hosts'

    @classmethod
    def filter(cls, label_value) -> bool:
        return socket.gethostname() in label_value


class _ContainerLabelFilter(_LabelFilter):
    @classmethod
    def name(cls) -> str:
        return 'container'

    @classmethod
    def filter(cls, label_value) -> bool:
        # Ref: https://stackoverflow.com/a/25518538/9531266
        return os.path.isfile('/.dockerenv')


class _ArchLabelFilter(_LabelFilter):
    @classmethod
    def name(cls) -> str:
        return 'arch'

    @classmethod
    def filter(cls, label_value) -> bool:
        arch = subprocess.run('uname -m', stdout=subprocess.PIPE, shell=True, check=True).stdout.decode().rstrip('\n')
        return arch == label_value


_label_filter_list = [
    _HostsLabelFilter,
    _ContainerLabelFilter,
    _ArchLabelFilter,
]
_label_filter_dict = {
    label_filter.name(): label_filter
    for label_filter in _label_filter_list
}
assert len(_label_filter_dict) == len(_label_filter_list), 'There are duplicate label names.'


class Dotfile:
    def __init__(self, config: dict):
        self.name = config['name']
        self.path = config['path']

        self.labels = config.get('labels', {})

        # If starts with '/', it's the absolute path. Otherwise, it's the path relative to the home directory.
        self.deploy_path = config['deploy_path'] if 'deploy_path' in config else config['path']

        if 'action_on_exist' in config:
            assert config['action_on_exist'] in ['replace', 'backup_and_replace', 'keep_old_and_warn'], \
                'Invalid "action_on_exist" for item "{}": "{}"'.format(config['name'], config['action_on_exist'])

        self.action_on_exist = getattr(ActionOnExist,
                                       config.get('action_on_exist', _DEFAULT_ACTION_ON_EXIST_CONFIG).upper())

    @property
    def source_path(self):
        return os.path.join(_FILE_DIR, _CONFIG_BASE_DIR, self.path)

    @property
    def destination_path(self):
        destination_path = \
            self.deploy_path if self.deploy_path.startswith('/') \
            else os.path.expanduser(os.path.join('~', self.deploy_path))
        assert not destination_path.endswith('/'), 'Invalid destination path: "{}".'.format(destination_path)
        return destination_path

    @property
    def destination_dir(self):
        return os.path.dirname(self.destination_path)

    @property
    def destination_basename(self):
        return os.path.basename(self.destination_path)

    def should_apply(self):
        """
        Determine if the dotfile should apply to the current environment based on labels.
        """
        for label_name, label_value in self.labels.items():
            if label_name not in _label_filter_dict:
                raise ValueError('Label "{}" is not supported.'.format(label_name))
            is_rule_passed = _label_filter_dict[label_name].filter(label_value)
            if not is_rule_passed:
                return False
        return True

    def __str__(self):
        return 'Dotfile(name=\'{}\')'.format(self.name)


def _deploy(dotfile: Dotfile):
    """
    TODO(yanqingwang): migrate the checkings to one upper level so that it can be shared by other modes.
    """
    source_file_path = dotfile.source_path

    if not os.path.exists(source_file_path):
        logger.error('Config file "{}" doesn\'t exist. Failed to deploy.'.format(source_file_path))
        return

    if not os.path.isfile(source_file_path):
        logger.error('Config path "{}" is not a file. Failed to deploy.'.format(source_file_path))
        return

    destination_path = dotfile.destination_path
    destination_dir = dotfile.destination_dir

    can_write_to_destination_dir = os.access(destination_dir, os.W_OK | os.X_OK)
    # TODO(yanqingwang): add sudo to other commands when needed.
    # TODO(yanqingwang): if there is already a file created by root, we will get "Permission denied" now.
    sudo_prefix = ['sudo'] if not can_write_to_destination_dir else []

    success_log_str = 'Deployed file "{}"("{}") to "{}".'.format(dotfile.name, source_file_path, destination_path)

    if os.path.exists(destination_path):
        destination_path_basename = dotfile.destination_basename

        if not os.path.isfile(destination_path):
            logger.error('Destination path "{}" exists, but is not a file. Failed to deploy.'.format(destination_path))
            return

        is_existing_same = subprocess.call(['cmp', '-s', destination_path, source_file_path]) == 0

        if is_existing_same:
            logger.info('Omitted file "{}"("{}") because the exising one ("{}") is the same.'.format(
                dotfile.name, source_file_path, destination_path))

        else:
            if dotfile.action_on_exist == ActionOnExist.REPLACE:
                subprocess.run([*sudo_prefix, 'cp', source_file_path, destination_path], check=True)
                logger.success(success_log_str + ' The old one is overwritten.')

            elif dotfile.action_on_exist == ActionOnExist.BACKUP_AND_REPLACE:
                subprocess.run([*sudo_prefix, 'cp', destination_path, '{}/{}.bak.{}'.format(
                    destination_dir, destination_path_basename, int(time.time())
                )], check=True)
                subprocess.run([*sudo_prefix, 'cp', source_file_path, destination_path], check=True)
                logger.success(success_log_str + ' The old one is backed up.')

            elif dotfile.action_on_exist == ActionOnExist.KEEP_OLD_AND_WARN:
                logger.warning('Did not deploy file "{}"("{}") to "{}" due to the existing one.'.format(
                    dotfile.name, source_file_path, destination_path))

    else:
        os.makedirs(destination_dir, exist_ok=True)
        subprocess.run([*sudo_prefix, 'cp', source_file_path, destination_path], check=True)
        logger.success(success_log_str)


def _clean_file(dotfile: Dotfile):
    remove_success = subprocess.run(['rm', dotfile.destination_path]).returncode == 0
    if remove_success:
        logger.success('Removed config file for "{}": "{}"'.format(dotfile.name,  dotfile.destination_path))


def _clean_backups(dotfile: Dotfile):
    destination_dir = dotfile.destination_dir
    destination_basename = dotfile.destination_basename
    backup_file_pattern = '{}/{}.bak.*'.format(destination_dir, destination_basename)

    # TODO(yanqingwang): avoid using shell feature.
    #
    # TODO(yanqingwang): handle the case when no backup file is found in a
    # better way (now the error message is put to stderr directly).
    remove_success = subprocess.call('rm ' + backup_file_pattern, shell=True) == 0

    if remove_success:
        logger.success('Removed backup files for "{}": "{}"'.format(dotfile.name, backup_file_pattern))


def _show_diff_if_exist(dotfile: Dotfile):
    source_file_path = dotfile.source_path
    destination_path = dotfile.destination_path

    if os.path.exists(destination_path):
        cmd = ['diff', '-u', '--color=always', destination_path, source_file_path]

        diff_process = subprocess.run(cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
        # This is commented out (replaced by the line above) to be compatible with Python 3.6.
        # -----
        # diff_process = subprocess.run(cmd, capture_output=True) # For Python >= 3.7

        if diff_process.returncode == 0:
            pass
        elif diff_process.returncode == 1:
            print()
            print('#' * 80)
            print('# {} ({})'.format(dotfile.name, source_file_path))
            print('#' * 80)
            print()
            print(diff_process.stdout.decode())
        else:
            raise RuntimeError('An error occurs when running "{}". stderr: "{}". Return code: {}.'.format(
                cmd, diff_process.stderr.decode(), diff_process.returncode))


def _load_config():
    config_path = os.path.join(os.getcwd(), _CONFIG_FILE_NAME)

    with open(config_path) as config_file:
        try:
            return yaml.safe_load(config_file)
        except yaml.YAMLError as e:
            logger.error(traceback.format_exc())
            raise e


def _get_args():
    parser = argparse.ArgumentParser()
    parser.add_argument('--clean', action='store_true', help='Clean the config and backup files.')
    parser.add_argument('--clean-baks', action='store_true', help='Clean the backup files.')
    parser.add_argument('--diff', action='store_true', help='Show the diff of the config files and the existing ones.')
    return parser.parse_args()


def _get_mode(args) -> str:
    assert sum(getattr(args, mode_arg) for mode_arg in ['clean', 'clean_baks', 'diff']) <= 1, \
        'More than one mode arguments are given. Accept at most one.'

    if args.clean:
        mode = 'clean'
    elif args.clean_baks:
        mode = 'clean-baks'
    elif args.diff:
        mode = 'diff'
    else:
        mode = 'deploy'

    return mode


# Map mode names to the handlers. Each handler should receive a 'Dotfile' object.
_mode_handlers = {
    'deploy': [_deploy],
    'clean': [_clean_file, _clean_backups],
    'clean-baks': [_clean_backups],
    'diff': [_show_diff_if_exist]
}


def main():
    args = _get_args()
    mode = _get_mode(args)

    config = _load_config()

    handlers = _mode_handlers[mode]
    for dotfile_item_config in config:
        dotfile = Dotfile(dotfile_item_config)

        if not dotfile.should_apply():
            logger.warning('Omitted file "{}"("{}") because it does not apply.'.format(
                dotfile.name, dotfile.source_path))
            continue

        for handler in handlers:
            handler(dotfile)


if __name__ == '__main__':
    main()
