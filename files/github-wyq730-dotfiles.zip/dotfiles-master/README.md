# dotfiles

Dotfiles and related scripts.

## Run

Install requirements:

```sh
cd scripts
python3 -m pip install -r ./requirements.txt
```

Run the script:

```
./deploy.py -h
usage: deploy.py [-h] [--clean] [--clean-baks] [--diff]

options:
  -h, --help    show this help message and exit
  --clean       Clean the config and backup files.
  --clean-baks  Clean the backup files.
  --diff        Show the diff of the config files and the existing ones.
```
